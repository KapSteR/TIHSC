#ifndef POSITION_H_
#define POSITION_H_

struct Position{
	int x;
	int y;
//	float orientation;
	int orientation;
};

#endif /* POSITION_H_ */
