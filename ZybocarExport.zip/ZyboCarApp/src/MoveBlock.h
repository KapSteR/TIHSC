#ifndef MOVEBLOCK_H_
#define MOVEBLOCK_H_

struct MoveBlock{
	int distance;
	int angle;
	int turnAngle;
};

#endif /* POSITION_H_ */
